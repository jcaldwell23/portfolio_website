from dataclasses import dataclass

@dataclass
class Movie:
  title:str = ''
  genre:str = ''
  studio:str = ''
  audience_score:int = 0
  rt_score:int = 0
  gross_profit:float = 0.0
  release_year:str = ''
  movieID:int = 0


  @property
  def average_score(self):
     return (self.audience_score + self.rt_score) / 2

@dataclass
class MovieList:
    def __init__(self):
        self.__list = []

    @property
    def count(self):
        return len(self.__list)

    def add(self, movie):
        return self.__list.append(movie)
    
    def remove(self, number):
        return self.__list.pop(number-1)

    def __iter__(self):
      for player in self.__list:
        yield player