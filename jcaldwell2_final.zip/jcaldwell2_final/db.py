import sqlite3
from contextlib import closing
from business import Movie, MovieList

conn = None

def connect():
    global conn
    if not conn:
        DB_FILE = 'Final.sqlite'
        conn = sqlite3.connect(DB_FILE)
        conn.row_factory = sqlite3.Row

def close():
    if conn:
        conn.close()

def make_movie(row):
    return Movie(row["title"], row["genre"],
                 row["studio"], row['audience_score'], row['rt_score'], 
                 row["gross_profit"], row["release_year"], row["movieID"])

def get_movies():
    sql = '''
            SELECT movieID, title, genre, studio, audience_score, rt_score, gross_profit, release_year
            FROM movie_tbl
            ORDER BY movieID
          '''
    with closing(conn.cursor()) as c:
        c.execute(sql)
        results = c.fetchall()

    movies = MovieList()
    for row in results:
        movie = make_movie(row)
        movies.add(movie)
    return movies

def filter_genre(genre):
    sql = '''
            SELECT movieID, title, genre, studio, audience_score, rt_score, gross_profit, release_year
            FROM movie_tbl
            WHERE genre = ?
            ORDER BY movieID
          '''
    with closing(conn.cursor()) as c:
        c.execute(sql, (genre,))
        results = c.fetchall()

    movies = MovieList()
    for row in results:
        movie = make_movie(row)
        movies.add(movie)
    return movies

def filter_year(year):
    sql = '''
            SELECT movieID, title, genre, studio, audience_score, rt_score, gross_profit, release_year
            FROM movie_tbl
            WHERE release_year = ?
            ORDER BY movieID
          '''
    with closing(conn.cursor()) as c:
        c.execute(sql, (year,))
        results = c.fetchall()

    movies = MovieList()
    for row in results:
        movie = make_movie(row)
        movies.add(movie)
    return movies

def sort_by_title():
    sql = '''
            SELECT movieID, title, genre, studio, audience_score, rt_score, gross_profit, release_year
            FROM movie_tbl
            ORDER BY title
          '''

    with closing(conn.cursor()) as c:
        c.execute(sql)
        results = c.fetchall()

    movies = MovieList()
    for row in results:
        movie = make_movie(row)
        movies.add(movie)
    return movies

def sort_by_profit():
    sql = '''
            SELECT movieID, title, genre, studio, audience_score, rt_score, gross_profit, release_year
            FROM movie_tbl
            ORDER BY gross_profit DESC
          '''

    with closing(conn.cursor()) as c:
        c.execute(sql)
        results = c.fetchall()

    movies = MovieList()
    for row in results:
        movie = make_movie(row)
        movies.add(movie)
    return movies

def add_movie(movie):
    sql = '''
            INSERT INTO movie_tbl (title, genre, studio, audience_score, rt_score, gross_profit, release_year)
            VALUES (?,?,?,?,?,?,?)
          '''
    with closing(conn.cursor()) as c:
        c.execute(sql, (movie.title, movie.genre, movie.studio, movie.audience_score, movie.rt_score, movie.gross_profit, movie.release_year))
        conn.commit()
