import db
from business import Movie, MovieList

GENRES = ('Action, Animation, Comedy, Drama, Fantasy, Romance')
YEARS = ('2007, 2008, 2009, 2010, 2011')

def add_movie(movies):
  title = input("Title: ").upper()
  genre = get_genre()
  studio = input("Studio: ").title()
  audience_score = int(input("Audience Score: "))
  rt_score = int(input("Rotten Tomatoes Score: "))
  gross_profit = float(input("Gross Profit: "))
  release_year = get_year()

  movie = Movie(title, genre, studio, audience_score, rt_score, gross_profit, release_year)
  movies.add(movie)
  db.add_movie(movie)
  print(f"{movie.title} was added\n")
           
def get_genre():
  while True:
    genre = input("Genre: ").title()
    if genre in GENRES:
      return genre
    else:
      print('Invalid Genre. Please try again.')
      display_genres()

def get_year():
  while True:
    year = input("Release year: ")
    if year in YEARS:
      return year
    else:
      print('Invalid Year. Please try again.')
      display_years()

def display_genres():
  print('GENRES')
  print(f'{GENRES}')

def display_years():
  print('YEARS')
  print(f'{YEARS}')

def display_movies(movies):
  if movies == None:
    print('There are no movies to display.')
  else:
    print()
    print(f'{'TITLE':32}\t{'GENRE':10}\t{'STUDIO':20}\t{'AS SCORE':>5}\t{'RT SCORE':<10}\t{'PROFIT $ (IN MILLIONS)':10}\t{'RELEASE YEAR':1}\t{'AVG SCORE':>10}')
    print('-' * 170)
    for movie in movies:
      print(f'{movie.title:35}\t{movie.genre:10}\t{movie.studio:20}\t{movie.audience_score:>5}\t{movie.rt_score:>13}\t{movie.gross_profit:>22}\t{movie.release_year:>20}\t{movie.average_score:>7.1f}%\n')
    print('-' * 170)
    print(f'{movies.count:>5} movies')
    print()

def display_separator():
  print("=" * 64)

def display_title():
  print("                   Top Grossing Movies Worldwide 2007-2011")

def display_menu():
  print("MENU OPTIONS")
  print("1 – Display movies")
  print("2 – Filter movies")
  print("3 – Sort movies")
  print("4 – Add movie")
  print("5 – Show menu")
  print("6 - Exit program")
  print()

def display_filter_menu():
  print('1 - Genre')
  print('2 - Year')
  print('3 - Go back')

def display_sort_menu():
  print('1 - A-Z')
  print('2 - Gross Profit')
  print('3 - Go back')

def main():
  # Display menu
  display_separator()
  display_title()
  display_menu()
  display_separator()
  print()

  # connect and populate movies
  db.connect()
  movies = db.get_movies()

  if movies == None:
     movies = MovieList()

  # Main Menu
  while True:
    option = int(input('Menu option: '))
    print()

    if option == 1:
      display_movies(movies)
    elif option == 2:
      # Entered Filter Menu
      while True:
        filtered_movies = MovieList()
        print('Filtering Options')
        display_filter_menu()
        sub_option = int(input('Filter option: '))

        if sub_option == 1: # Filter by genre
          print()
          display_genres()
          genre = (input('Enter genre: ')).title()
          if genre in GENRES:
            filtered_movies = db.filter_genre(genre)
            display_movies(filtered_movies)
          else:
            print('Genre not found. Please try again.')

        elif sub_option == 2: # Filter by year
          print()
          display_years()
          year = (input('Enter year: '))
          if year in YEARS:
            filtered_movies = db.filter_year(year)
            display_movies(filtered_movies)
          else:
            print('Year not found. Please try again.')

        elif sub_option == 3: # Go back to previous menu
          print()
          break
        else:
          print('Not a valid option. Please try again.\n')

    # Back to Main Menu
    elif option == 3:
      # Entered Sort Menu
      while True:
        sorted_movies = MovieList()
        print('Sorting Options')
        display_sort_menu()
        sub_option = int(input('Sort option: '))

        if sub_option == 1: # sort by title
          print()
          sorted_movies = db.sort_by_title()
          display_movies(sorted_movies)

        elif sub_option == 2: # sort by profit
          print()
          sorted_movies = db.sort_by_profit()
          display_movies(sorted_movies)
        
        elif sub_option == 3: # Go back to previous menu
          print()
          break
        else:
          print('Not a valid option. Please try again.\n')

    #Back to Main Menu
    elif option == 4:
      add_movie(movies)
    elif option == 5:
      display_menu()
    elif option == 6:   # Exit
      db.close()
      print('Exited.')
      break
    else:
      print('Not a valid option. Please try again.\n')

if __name__ == '__main__':
  main()
