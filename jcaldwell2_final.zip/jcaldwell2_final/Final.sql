--
-- File generated with SQLiteStudio v3.4.4 on Tue May 14 21:46:52 2024
--
-- Text encoding used: UTF-8
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: movie_tbl
DROP TABLE IF EXISTS movie_tbl;

CREATE TABLE IF NOT EXISTS movie_tbl (
    movieID        INTEGER PRIMARY KEY AUTOINCREMENT
                           NOT NULL,
    title          TEXT    NOT NULL,
    genre          TEXT    NOT NULL,
    studio         TEXT    NOT NULL,
    audience_score INTEGER,
    rt_score       INTEGER,
    gross_profit   INTEGER NOT NULL,
    release_year   TEXT    NOT NULL
);

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          2,
                          'YOUTH IN REVOLT',
                          'Comedy',
                          'The Weinstein Company',
                          52,
                          68,
                          19.62,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          3,
                          'YOU WILL MEET A TALL DARK STRANGER',
                          'Comedy',
                          'Independent',
                          35,
                          43,
                          26.66,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          4,
                          'WHEN IN ROME',
                          'Comedy',
                          'Disney',
                          44,
                          15,
                          43.04,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          5,
                          'WHAT HAPPENS IN VEGAS',
                          'Comedy',
                          'Fox',
                          72,
                          28,
                          219.37,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          6,
                          'WATER FOR ELEPHANTS',
                          'Drama',
                          '20th Century Fox',
                          72,
                          60,
                          117.09,
                          '2011'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          7,
                          'WALL-E',
                          'Animation',
                          'Disney',
                          89,
                          96,
                          521.28,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          8,
                          'WAITRESS',
                          'Romance',
                          'Independent',
                          67,
                          89,
                          22.18,
                          '2007'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          9,
                          'WAITING FOR FOREVER',
                          'Romance',
                          'Independent',
                          53,
                          6,
                          0.03,
                          '2011'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          10,
                          'VALENTINE''S DAY',
                          'Comedy',
                          'Warner Bros.',
                          54,
                          17,
                          217.57,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          11,
                          'TYLER PERRY''S WHY DID I GET MARRIED',
                          'Romance',
                          'Independent',
                          47,
                          46,
                          55.86,
                          '2007'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          12,
                          'TWILIGHT: BREAKING DAWN',
                          'Romance',
                          'Independent',
                          68,
                          26,
                          702.17,
                          '2011'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          13,
                          'TWILIGHT',
                          'Romance',
                          'Summit',
                          82,
                          49,
                          376.66,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          14,
                          'THE UGLY TRUTH',
                          'Comedy',
                          'Independent',
                          68,
                          14,
                          205.3,
                          '2009'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          15,
                          'THE TWILIGHT SAGA: NEW MOON',
                          'Drama',
                          'Summit',
                          78,
                          27,
                          709.82,
                          '2009'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          16,
                          'THE TIME TRAVELER''S WIFE',
                          'Drama',
                          'Paramount',
                          65,
                          38,
                          101.33,
                          '2009'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          17,
                          'THE PROPOSAL',
                          'Comedy',
                          'Disney',
                          74,
                          43,
                          314.7,
                          '2009'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          18,
                          'THE INVENTION OF LYING',
                          'Comedy',
                          'Warner Bros.',
                          47,
                          56,
                          32.4,
                          '2009'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          19,
                          'THE HEARTBREAK KID',
                          'Comedy',
                          'Paramount',
                          41,
                          30,
                          127.77,
                          '2007'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          20,
                          'THE DUCHESS',
                          'Drama',
                          'Paramount',
                          68,
                          60,
                          43.31,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          21,
                          'THE CURIOUS CASE OF BENJAMIN BUTTON',
                          'Fantasy',
                          'Warner Bros.',
                          81,
                          73,
                          285.43,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          22,
                          'THE BACK-UP PLAN',
                          'Comedy',
                          'CBS',
                          47,
                          20,
                          77.09,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          23,
                          'TANGLED',
                          'Animation',
                          'Disney',
                          88,
                          89,
                          355.01,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          24,
                          'SOMETHING BORROWED',
                          'Romance',
                          'Independent',
                          48,
                          15,
                          60.18,
                          '2011'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          25,
                          'SHE''S OUT OF MY LEAGUE',
                          'Comedy',
                          'Paramount',
                          60,
                          57,
                          48.81,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          26,
                          'SEX AND THE CITY TWO',
                          'Comedy',
                          'Warner Bros.',
                          49,
                          15,
                          288.35,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          27,
                          'SEX AND THE CITY 2',
                          'Comedy',
                          'Warner Bros.',
                          49,
                          15,
                          288.35,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          28,
                          'SEX AND THE CITY',
                          'Comedy',
                          'Warner Bros.',
                          81,
                          49,
                          415.25,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          29,
                          'REMEMBER ME',
                          'Drama',
                          'Summit',
                          70,
                          28,
                          55.86,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          30,
                          'RACHEL GETTING MARRIED',
                          'Drama',
                          'Independent',
                          61,
                          85,
                          16.61,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          31,
                          'PENELOPE',
                          'Comedy',
                          'Summit',
                          74,
                          52,
                          20.74,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          32,
                          'P.S. I LOVE YOU',
                          'Romance',
                          'Independent',
                          82,
                          21,
                          153.09,
                          '2007'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          33,
                          'OVER HER DEAD BODY',
                          'Comedy',
                          'New Line',
                          47,
                          15,
                          20.71,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          34,
                          'OUR FAMILY WEDDING',
                          'Comedy',
                          'Independent',
                          49,
                          14,
                          21.37,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          35,
                          'ONE DAY',
                          'Romance',
                          'Independent',
                          54,
                          37,
                          55.24,
                          '2011'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          36,
                          'NOT EASILY BROKEN',
                          'Drama',
                          'Independent',
                          66,
                          34,
                          10.7,
                          '2009'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          37,
                          'NO RESERVATIONS',
                          'Comedy',
                          'Warner Bros.',
                          64,
                          39,
                          92.6,
                          '2007'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          38,
                          'NICK AND NORAH''S INFINITE PLAYLIST',
                          'Comedy',
                          'Sony',
                          67,
                          73,
                          33.53,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          39,
                          'NEW YEAR''S EVE',
                          'Romance',
                          'Warner Bros.',
                          48,
                          8,
                          142.04,
                          '2011'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          40,
                          'MY WEEK WITH MARILYN',
                          'Drama',
                          'The Weinstein Company',
                          84,
                          83,
                          8.26,
                          '2011'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          41,
                          'MUSIC AND LYRICS',
                          'Romance',
                          'Warner Bros.',
                          70,
                          63,
                          145.9,
                          '2007'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          42,
                          'MONTE CARLO',
                          'Romance',
                          '20th Century Fox',
                          50,
                          38,
                          39.66,
                          '2011'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          43,
                          'MISS PETTIGREW LIVES FOR A DAY',
                          'Comedy',
                          'Independent',
                          70,
                          78,
                          15.17,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          44,
                          'MIDNIGHT IN PARIS',
                          'Romence',
                          'Sony',
                          84,
                          93,
                          148.66,
                          '2011'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          45,
                          'MARLEY AND ME',
                          'Comedy',
                          'Fox',
                          77,
                          63,
                          206.07,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          47,
                          'MAMMA MIA!',
                          'Comedy',
                          'Universal',
                          76,
                          53,
                          609.47,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          48,
                          'MADE OF HONOR',
                          'Comdy',
                          'Sony',
                          61,
                          13,
                          105.96,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          49,
                          'LOVE HAPPENS',
                          'Drama',
                          'Universal',
                          40,
                          18,
                          36.08,
                          '2009'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          50,
                          'LOVE & OTHER DRUGS',
                          'Comedy',
                          'Fox',
                          55,
                          48,
                          54.53,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          51,
                          'LIFE AS WE KNOW IT',
                          'Comedy',
                          'Independent',
                          62,
                          28,
                          96.16,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          52,
                          'LICENSE TO WED',
                          'Comedy',
                          'Warner Bros.',
                          55,
                          8,
                          69.31,
                          '2007'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          53,
                          'LETTERS TO JULIET',
                          'Comedy',
                          'Summit',
                          62,
                          40,
                          79.18,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          54,
                          'LEAP YEAR',
                          'Comedy',
                          'Universal',
                          49,
                          21,
                          32.59,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          55,
                          'KNOCKED UP',
                          'Comedy',
                          'Universal',
                          83,
                          91,
                          219,
                          '2007'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          56,
                          'KILLERS',
                          'Action',
                          'Lionsgate',
                          45,
                          11,
                          93.4,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          57,
                          'JUST WRIGHT',
                          'Comedy',
                          'Fox',
                          58,
                          45,
                          21.57,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          58,
                          'JANE EYRE',
                          'Romance',
                          'Universal',
                          77,
                          85,
                          30.15,
                          '2011'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          59,
                          'IT''S COMPLICATED',
                          'Comedy',
                          'Universal',
                          63,
                          56,
                          224.6,
                          '2009'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          60,
                          'I LOVE YOU PHILLIP MORRIS',
                          'Comedy',
                          'Independent',
                          57,
                          71,
                          20.1,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          61,
                          'HIGH SCHOOL MUSICAL 3: SENIOR YEAR',
                          'Comedy',
                          'Disney',
                          76,
                          65,
                          252.04,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          62,
                          'HE''S JUST NOT THAT INTO YOU',
                          'Comedy',
                          'Warner Bros.',
                          60,
                          42,
                          178.84,
                          '2009'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          63,
                          'GOOD LUCK CHUCK',
                          'Comedy',
                          'Lionsgate',
                          61,
                          3,
                          59.19,
                          '2007'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          64,
                          'GOING THE DISTANCE',
                          'Comedy',
                          'Warner Bros.',
                          56,
                          53,
                          42.05,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          65,
                          'GNOMEO AND JULIET',
                          'Animation',
                          'Disney',
                          52,
                          56,
                          193.97,
                          '2011'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          67,
                          'GHOSTS OF GIRLFRIENDS PAST',
                          'Comedy',
                          'Warner Bros.',
                          47,
                          27,
                          102.22,
                          '2009'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          68,
                          'FOUR CHRISTMASES',
                          'Comedy',
                          'Warner Bros.',
                          52,
                          26,
                          161.83,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          69,
                          'FIREPROOF',
                          'Drama',
                          'Independent',
                          51,
                          40,
                          33.47,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          70,
                          'ENCHANTED',
                          'Comedy',
                          'Disney',
                          80,
                          93,
                          340.49,
                          '2007'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          71,
                          'DEAR JOHN',
                          'Drama',
                          'Sony',
                          66,
                          29,
                          114.97,
                          '2010'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          72,
                          'BEGINNERS',
                          'Comedy',
                          'Independent',
                          80,
                          84,
                          14.31,
                          '2011'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          73,
                          'ACROSS THE UNIVERSE',
                          'romance',
                          'Independent',
                          84,
                          54,
                          29.37,
                          '2007'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          74,
                          'A SERIOUS MAN',
                          'Drama',
                          'Universal',
                          64,
                          89,
                          30.68,
                          '2009'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          75,
                          'A DANGEROUS METHOD',
                          'Drama',
                          'Independent',
                          89,
                          79,
                          8.97,
                          '2011'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          76,
                          '27 DRESSES',
                          'Comedy',
                          'Fox',
                          71,
                          40,
                          160.31,
                          '2008'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          83,
                          'PUBLIC ENEMIES',
                          'Action',
                          'Netflix',
                          75,
                          68,
                          214,
                          '2009'
                      );

INSERT INTO movie_tbl (
                          movieID,
                          title,
                          genre,
                          studio,
                          audience_score,
                          rt_score,
                          gross_profit,
                          release_year
                      )
                      VALUES (
                          84,
                          'BURIED',
                          'Drama',
                          'Warner Bros.',
                          67,
                          87,
                          21.3,
                          '2010'
                      );


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
