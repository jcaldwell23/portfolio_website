
// creates a table and fills it with player info
function displayTableRow() {

  let table = document.getElementById("myTable");

  for (let counter = 0; counter < players.length; counter++) {
    // creates a row <tr>
    let row = table.insertRow(counter + 1);

    // creates a data point in each row <td>
    let playerName = row.insertCell(0);
    let numWins = row.insertCell(1);
    let numHomeRuns = row.insertCell(2);
    let numHits = row.insertCell(3);
    let results = row.insertCell(4);

    // assigns input values to the data points
    playerName.innerHTML = players[counter];
    numWins.innerHTML = wins[counter];
    numHomeRuns.innerHTML = homeRuns[counter];
    numHits.innerHTML = hits[counter];
    
    // compares player stats to hall of fame stats
    if (wins[counter] >= 50 && homeRuns[counter] >= 500 && hits[counter] >= 3000) {
      results.innerHTML = "Worthy";
      results.style = "color: green";
    } else {
        results.innerHTML = "Unworthy";
        results.style = "color: red";
    }
  
  }
  
}

