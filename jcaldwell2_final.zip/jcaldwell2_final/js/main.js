
// Global arrays that store user inputs
let players = [];
let wins = [];
let homeRuns = [];
let hits = [];

// determines if a player is eligible for the hall of fame
function main() {

  getPlayerInfo();
  displayTableRow();

}

main();


