
// Get user input for players and their stats
function getPlayerInfo() {

  // sets the length of each array 
  players.length = Number(prompt("How many players would you like to check?"));


  for (let i = 0; i < players.length; i++) {
    // populates  the players array
    players[i] = prompt("Enter player name.");
    // populates  the wins array
    wins[i] = (prompt("What is " + players[i] + "\'s WAR?"));
    // populates the runs array
    homeRuns[i] = (prompt("How many home runs does " + players[i] + " have?"));
    // populates the hits array
    hits[i] = (prompt("How many hits does " + players[i] + " have?"));

    // checks to see if any input is a number
    if (isNaN(wins[i])) {
      wins[i] = 0;
    } else {
        wins[i] = Number(wins[i]);
    }
    if (isNaN(homeRuns[i])) {
      homeRuns[i] = 0;
    } else {
        homeRuns[i] = Number(homeRuns[i]);
    }
    if (isNaN(hits[i])) {
      hits[i] = 0;
    } else {
        hits[i] = Number(hits[i]);
    }
  }
}
